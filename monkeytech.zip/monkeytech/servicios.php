<?php include 'includes/header.php'; ?>

<main class="container">
  <section class="contenido-fondo">
    <h1>Servicios / Herramientas Estudiadas</h1>
    <p>A lo largo del curso, aprendimos sobre servicios esenciales que ofrecen los sistemas operativos para el manejo de recursos:</p>

    <ul>
      <li>Gestión de procesos</li>
      <li>Gestión de memoria</li>
      <li>Gestión de almacenamiento</li>
      <li>Gestión de dispositivos de entrada y salida</li>
      <li>Interfaz con el usuario</li>
    </ul>

    <p>Además, analizamos diferentes arquitecturas de sistemas y casos reales como Windows, Linux y Android.</p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>