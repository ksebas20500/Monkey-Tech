<?php include 'includes/header.php'; ?>

<main class="container">
  <section class="contenido-fondo">
    <h1>Gestión de Procesos</h1>
    <p>La gestión de procesos es una de las principales funciones del sistema operativo. Implica la creación, planificación y finalización de procesos.</p>

    <h2>Estados de un proceso:</h2>
    <ul>
      <li>Nuevo</li>
      <li>Listo</li>
      <li>En ejecución</li>
      <li>Bloqueado</li>
      <li>Finalizado</li>
    </ul>

    <h2>Algoritmos de planificación:</h2>
    <ul>
      <li>FIFO</li>
      <li>Round Robin</li>
      <li>Shortest Job First</li>
    </ul>

    <p>
      <a href="https://www.geeksforgeeks.org/process-management-in-os/" target="_blank">
        Más información sobre Gestión de procesos
      </a>
    </p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>