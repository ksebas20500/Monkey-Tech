// Animación al cargar
window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  if (loader) {
    loader.classList.add("fade-out");
    setTimeout(() => loader.remove(), 500);
  }

  const main = document.querySelector("main");
  if (main) {
    main.classList.add("fade-in");
  }
});

// Animación al salir (leer más)
document.addEventListener("DOMContentLoaded", () => {
  const enlaces = document.querySelectorAll(".temas a");

  enlaces.forEach(enlace => {
    enlace.addEventListener("click", (e) => {
      e.preventDefault();
      const destino = enlace.href;
      const main = document.querySelector("main");

      if (main) {
        main.classList.remove("fade-in");
        main.classList.add("fade-out");

        setTimeout(() => {
          window.location.href = destino;
        }, 500);
      } else {
        window.location.href = destino;
      }
    });
  });
});
