<?php include 'includes/header.php'; ?>

<main class="container">
  <section class="contenido-fondo">
    <h1>Introducción a los Sistemas Operativos</h1>
    <p>Un sistema operativo es un software que actúa como intermediario entre el hardware de un computador y el usuario. Administra los recursos y permite la ejecución de aplicaciones.</p>

    <h2>Funciones clave:</h2>
    <ul>
      <li>Gestión de procesos</li>
      <li>Gestión de memoria</li>
      <li>Gestión de almacenamiento</li>
      <li>Interfaz de usuario</li>
    </ul>

    <h2>Tipos de Sistemas Operativos:</h2>
    <p>Entre los principales tipos están:</p>
    <ul>
      <li>Monolíticos (como MS-DOS)</li>
      <li>Por capas (como THE)</li>
      <li>Microkernel (como MINIX)</li>
      <li>Distribuidos</li>
      <li>Tiempo real</li>
    </ul>

    <p><a href="https://es.wikipedia.org/wiki/Sistema_operativo" target="_blank">Más información sobre los Sistemas Operativos</a></p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>