<?php include 'includes/header.php'; ?>

<main class="container">
  <section class="contenido-fondo">
    <h1>Gestión de Almacenamiento</h1>
    <p>La gestión de almacenamiento es una función fundamental del sistema operativo que permite guardar y recuperar datos de manera organizada y segura.</p>

    <h2>Componentes clave:</h2>
    <ul>
      <li>Dispositivos de almacenamiento (discos duros, SSD, USB)</li>
      <li>Sistemas de archivos (FAT32, NTFS, ext4)</li>
      <li>Jerarquía de almacenamiento: caché, RAM, almacenamiento secundario</li>
    </ul>

    <h2>Responsabilidades del sistema operativo:</h2>
    <ul>
      <li>Administrar espacios libres y ocupados</li>
      <li>Leer y escribir archivos</li>
      <li>Controlar permisos de acceso</li>
      <li>Realizar respaldos y restauraciones</li>
    </ul>

    <p>Los sistemas modernos emplean técnicas avanzadas como journaling para evitar la pérdida de datos ante fallos.</p>
    
    <p>
      <a href="https://www.redhat.com/es/topics/storage/what-is-storage-management" target="_blank">
        Más información sobre Gestión de almacenamiento
      </a>
    </p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>