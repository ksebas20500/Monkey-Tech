<?php include 'includes/header.php'; ?>

<main class="container">

  <!-- Banner representativo -->
  <section class="banner">
    <img src="images/banner.png" alt="Banner representativo del tema">
  </section>

  <!-- Introducción general -->
  <section class="contenido">
    <h1>Plataformas Tecnológicas</h1>
    <p>En esta página se exponen los principales conceptos estudiados durante el semestre en el área de plataformas tecnológicas. A continuación, se presentan los temas junto a sus respectivos contenidos y enlaces de referencia.</p>
  </section>

  <!-- Temas -->
  <section class="temas">
    <article>
      <h2>1. Introducción a los Sistemas Operativos</h2>
      <p>Estudia qué es un sistema operativo, su historia, tipos y funciones principales en la administración del sistema.</p>
      <a href="sistemas.php">Leer más →</a>
    </article>

    <article>
      <h2>2. Gestión de Procesos</h2>
      <p>Explica cómo el sistema operativo controla y organiza los procesos que se ejecutan en un equipo, su planificación y estados.</p>
      <a href="procesos.php">Leer más →</a>
    </article>

    <article>
      <h2>3. Gestión de Memoria</h2>
      <p>Describe cómo se asigna, organiza y optimiza el uso de la memoria RAM entre procesos y servicios del sistema.</p>
      <a href="memoria.php">Leer más →</a>
    </article>

    <article>
      <h2>4. Gestión de Almacenamiento</h2>
      <p>Se enfoca en cómo se gestionan los discos y sistemas de archivos para guardar y recuperar datos eficientemente.</p>
      <a href="almacenamiento.php">Leer más →</a>
    </article>
  </section>

</main>

<?php include 'includes/footer.php'; ?>