<?php include 'includes/header.php'; ?>
<div id="loader">Cargando...</div>

<main class="container">
  <section class="contenido-fondo">
    <h1>Gestión de Memoria</h1>
    <p>La gestión de memoria es la función del sistema operativo que se encarga de asignar y liberar espacio en la memoria principal (RAM) para que los procesos puedan ejecutarse eficientemente.</p>

    <h2>Funciones principales:</h2>
    <ul>
      <li>Asignación de memoria a procesos</li>
      <li>Seguimiento del uso de la memoria</li>
      <li>Liberación de memoria cuando ya no se necesita</li>
      <li>Evitar conflictos de acceso entre procesos</li>
    </ul>

    <h2>Métodos de gestión:</h2>
    <ul>
      <li>Memoria contigua</li>
      <li>Paginación</li>
      <li>Segmentación</li>
      <li>Memoria virtual</li>
    </ul>

    <p>
      <a href="https://es.wikipedia.org/wiki/Gesti%C3%B3n_de_memoria" target="_blank">
        Más información sobre Gestión de Memoria
      </a>
    </p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>