<?php include 'includes/header.php'; ?>

<main class="container">
  <section class="contenido-fondo">
    <h1>Nosotros</h1>
    <p>Somos un equipo comprometido con la enseñanza y aprendizaje de las plataformas tecnológicas. Este sitio fue desarrollado como parte del curso, abordando temas clave de sistemas operativos y su administración.</p>

    <p>Nuestra misión es facilitar el acceso al conocimiento técnico mediante herramientas visuales, navegación clara y contenidos útiles.</p>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>