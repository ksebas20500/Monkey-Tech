<?php include 'includes/header.php'; ?>
<div id="loader">Cargando...</div>

<main class="container">
  <section class="contenido-fondo">
    <h1>Nosotros</h1>
    <p>Somos un equipo comprometido con la enseñanza y aprendizaje de las plataformas tecnológicas. Este sitio fue desarrollado como parte del curso, abordando temas clave de sistemas operativos y su administración.</p>

    <p>Nuestra misión es facilitar el acceso al conocimiento técnico mediante herramientas visuales, navegación clara y contenidos útiles.</p>

    <!-- Integrantes del equipo -->
    <section class="equipo">
      <div class="card-integrante">
        <img src="images/javier_mono.png" alt="Javier">
        <h3>Javier</h3>
        <p>Desarrollador principal</p>
      </div>

      <div class="card-integrante">
        <img src="images/kevin_mono.png" alt="Kevin">
        <h3>Kevin</h3>
        <p>Diseñador</p>
      </div>

      <div class="card-integrante">
        <img src="images/juan_mono.png" alt="Juan">
        <h3>Juan</h3>
        <p>tester</p>
      </div>
    </section>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>
