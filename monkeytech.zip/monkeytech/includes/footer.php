<footer class="footer">
  <p>Contacto: paeztorres93@gmail.com | &copy; <?php echo date("Y"); ?> Monkey Tech. Todos los derechos reservados.</p>
</footer>

</body>
</html>