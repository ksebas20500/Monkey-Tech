<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Monkey Tech</title>
  <link rel="stylesheet" href="css/estilos.css" />
</head>
<body>

<header class="header">
  <div class="logo">Monkey Tech</div>
  <nav class="nav">
    <a href="monkeytech.php">Inicio</a>
    <a href="nosotros.php">Nosotros</a>
    <a href="servicios.php">Servicios</a>
    <a href="contacto.php">Contacto</a>
  </nav>
</header>
