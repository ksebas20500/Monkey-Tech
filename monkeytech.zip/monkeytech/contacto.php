<?php include 'includes/header.php'; ?>
<div id="loader">Cargando...</div>

<main class="container">
  <section class="contenido-fondo">
    <h1>Contacto</h1>
    <p>¿Tienes dudas o sugerencias? Contáctanos mediante el siguiente formulario:</p>

    <form action="#" method="post" class="formulario-contacto">
      <label for="nombre">Nombre:</label>
      <input type="text" id="nombre" name="nombre" required>

      <label for="correo">Correo:</label>
      <input type="email" id="correo" name="correo" required>

      <label for="mensaje">Mensaje:</label>
      <textarea id="mensaje" name="mensaje" rows="5" required></textarea>

      <button type="submit">Enviar</button>
    </form>

    <p><a href="monkeytech.php" class="btn-volver">← Volver al inicio</a></p>
  </section>
</main>

<?php include 'includes/footer.php'; ?>